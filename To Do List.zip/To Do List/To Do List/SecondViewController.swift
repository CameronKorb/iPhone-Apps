//
//  SecondViewController.swift
//  To Do List
//
//  Created by Cameron Korb on 1/20/17.
//  Copyright © 2017 CamKorbApps. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var toDoTextField: UITextField!
    
    @IBAction func addButton(_ sender: Any) {
    
        let itemsObject = UserDefaults.standard.object(forKey: "items")
        
        var items:[String]
        
        if let tempItems = itemsObject as? [String]{
            items = tempItems
            
            items.append(toDoTextField.text!)
            
        } else {
            items = [toDoTextField.text!]
        }
        
        UserDefaults.standard.set(items, forKey: "items")
        
        toDoTextField.text = ""
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
}

