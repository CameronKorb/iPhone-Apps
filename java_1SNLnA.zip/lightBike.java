//*******************************************************************
// NOTE: please read the 'More Info' tab to the right for shortcuts.
//*******************************************************************


import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;

public class lightBike extends JApplet implements Runnable, KeyListener, MouseListener, MouseMotionListener {
    int rows = 250;
    int cols = 250;
    double size = 2.5; 
    int win = 0;
    Thread t;
    int timeStep = 100;
    boolean inPlay = false;
    int [][] trails = new int [rows][cols];
    ArrayList <Double> xchord1 = new ArrayList <Double>();
    ArrayList <Double> ychord1 = new ArrayList <Double>();
    ArrayList <Double> xchord2 = new ArrayList <Double>();
    ArrayList <Double> ychord2 = new ArrayList <Double>();
    public void init(){
        bike1.x = 2;
        bike1.y = 2;
        bike2.x = 48;
        bike2.y = 48;

        bike1.dir = 0;
        bike1.x = 2.0;
        bike1.y = 2.0;

        bike2.dir = 2;
        bike2.x = 48.0;
        bike2.y = 48.0;
        setFocusable(true);
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
        t = new Thread(this);
        t.start();
    }

    public void paint(Graphics g){
        g.setColor(Color.black);
        g.fillRect(0, 0, 2000, 2000);

        g.setColor(Color.yellow);
        g.drawRect(0, 0, 500, 500);
        g.drawRect(1, 1, 499, 499);
        showStatus("direction" +bike1.dir + " x" +bike1.x + " y" + bike1.y + " inPlay" + inPlay + " direction" +bike2.dir + " x" +bike2.x + " y" + bike2.y );
        if (inPlay == true){
                    xchord1.add(bike1.x);
            ychord1.add(bike1.y);
            xchord2.add(bike2.x);
            ychord2.add(bike2.y);
            for (int i = 0; i < rows; i++){
                for (int j = 0; j < cols; j++){
                    if (trails [i][j] == 1){
                        g.setColor(Color.white);
                        g.fillRect((int)j*10, (int)i*10, 10, 10);
                    } repaint();
                    if (trails [i][j] == 2){
                        g.setColor(Color.green);
                        g.fillRect((int)j*10, (int)i*10, 10, 10);
                    } repaint();
                }

            }
        }
        if (inPlay == false){
            g.clearRect(0,0, 2000, 2000);
            g.clearRect(0, 0, 2000, 2000);
            g.setColor(Color.black);
            g.fillRect(0, 0, 2000, 2000);
            g.setColor(Color.yellow);
        g.drawRect(0, 0, 500, 500);
        g.drawRect(1, 1, 499, 499);
            g.setColor(Color.white);
            g.drawString("Welcome to LightBike", 200, 15);
            g.drawString("Click to Begin", 205, 30);
            g.drawString("Use a and d to control player 1", 150, 50);
            g.drawString("Use 4 and 6 to control player 1", 150, 70);
        }
        if (bike1.x >= 50 || bike1.x <= 0){
            
            g.setColor(Color.white);
            g.drawString("Player 2 wins", 250, 250);    
            inPlay = false;
        }
        if (bike1.y >= 50 || bike1.y <= 0){
            
            g.setColor(Color.white);
            g.drawString("Player 2 wins", 250, 250);
            inPlay = false;
        }
        if (bike2.x >= 50 || bike2.x <= 0){
            g.setColor(Color.white);
            g.drawString("Player 1 wins", 250, 250); 
            inPlay = false;
        }
        if (bike2.y >= 50 || bike2.y <= 0){
            g.setColor(Color.white);
            g.drawString("Player 1 wins", 250, 250); 
            inPlay = false;
        }
        if (win == 1){
            g.setColor(Color.white);
            g.drawString("Player 1 wins", 250, 250); 
        }
        if (win == 2){
            g.setColor(Color.white);
            g.drawString("Player 2 wins", 250, 250); 
        }
    }

    public void mousePressed(MouseEvent e){

    }

    public void keyReleased(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
        if (e.getKeyChar() == 'r'){ //doesn't work
            win = 0;
            inPlay = true;
            bike1.dir = 0;
            bike1.x = 2.0;
            bike1.y = 2.0;

            bike2.dir = 2;
            bike2.x = 48.0;
            bike2.y = 48.0;
        }
    }

    public void mouseClicked(MouseEvent e) {
        inPlay = true;
    }

    public void run() {

        try {
            while(true) {
                if (inPlay == true){   

                    bike1.move();
                    bike2.move();
                    trails [(int)bike1.x][(int)bike1.y] = 1;
                    trails [(int)bike2.x][(int)bike2.y] = 2;
                }

                if (bike1.x >= 50 || bike1.x <= 0)
                    inPlay = false;
                if (bike1.y >= 50 || bike1.y <= 0)
                    inPlay = false;
                if (bike2.x >= 50 || bike2.x <= 0)
                    inPlay = false;
                if (bike2.y >= 50 || bike2.y <= 0)
                    inPlay = false;
                    for (int j = 0; j < xchord1.size()-1; j++){
                    if (
                    ((bike2.x >= xchord1.get(j) && 
                    bike2.x <= xchord1.get(j) && 
                    bike2.y >= ychord1.get(j) && 
                    bike2.y <= ychord1.get(j)))){
                        inPlay = false;
                        win = 1;
                    }
                    if((bike1.x >= xchord2.get(j) && 
                    bike1.x <= xchord2.get(j) && 
                    bike1.y >= ychord2.get(j) && 
                    bike1.y <= ychord2.get(j))){
                        inPlay = false;
                        win = 2;
                    }
                }
                t.sleep(timeStep);
                repaint();
            }
        } catch (InterruptedException e) {}
    }

    public void keyPressed(KeyEvent e) {
        if(inPlay == true){
            if (e.getKeyChar() == 'a'){
                bike1.dir --;
            }
            if (e.getKeyChar() == 'd'){
                bike1.dir ++; 
            }
            if (e.getKeyChar() == '4'){
                bike2.dir ++;
            }
            if (e.getKeyChar() == '6'){
                bike2.dir --;
            }

        }
    }

    public void mouseReleased(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

    public void mouseDragged(MouseEvent e) {
        repaint();
    }

    public void mouseMoved(MouseEvent e) {
    }

}
class bike1{
    static double x, y;
    static int dir;
    static double v = 2;
    static void move() {
        if (dir == 0)
            x = x + 1;
        if (dir == 1)
            y = y + 1;
        if (dir == 2)
            x = x - 1;
        if (dir == 3)
            y = y - 1;
        if (dir > 3)
            dir = 0;
        if (dir < 0)
            dir = 3;

    }
}
class bike2{
    static double x, y;
    static int dir;
    static double v = 2;
    static void move() {
        if (dir == 0)
            x = x + 1;
        if (dir == 1)
            y = y + 1;
        if (dir == 2)
            x = x - 1;
        if (dir == 3)
            y = y - 1;
        if (dir > 3)
            dir = 0;
        if (dir < 0)
            dir = 3;
    }
}



